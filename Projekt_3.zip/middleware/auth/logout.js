/**
 * Kijelentkezteti a felhasználót, majd a login oldalra irányít /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};