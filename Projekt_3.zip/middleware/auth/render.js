/**
 * Megjeleníti a kért oldalt /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};