/**
 * Ellenőrzi az emailcímet és a hozzá tartozó jelszót, majd az indexre irányít /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};