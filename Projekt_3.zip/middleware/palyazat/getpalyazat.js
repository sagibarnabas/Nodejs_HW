/**
 * Kiírja a pályázat adatait /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};