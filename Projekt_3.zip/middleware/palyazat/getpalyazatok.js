/**
 * Kilistázza a pályázatok /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};