/**
 * Kilistázza a bírálókat /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};