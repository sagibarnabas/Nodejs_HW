/**
 * Törli a pályázatot /
 */
module.exports = function (objectrepository) {

    return function (req, res, next) {
        return next();
    };

};